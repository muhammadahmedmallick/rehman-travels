<?php

namespace App\Interfaces\Hotels;

use App\Interfaces\BaseInterface;

interface HotelShoppingInfoInterface extends BaseInterface {}
