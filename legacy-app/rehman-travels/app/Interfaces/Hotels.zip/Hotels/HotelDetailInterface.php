<?php

namespace App\Interfaces\Hotels;

use App\Interfaces\BaseInterface;

interface HotelDetailInterface extends BaseInterface {}
