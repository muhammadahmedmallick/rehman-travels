<?php

namespace App\Interfaces\Hotels;

use App\Interfaces\BaseInterface;

interface HotelShoppingCancellationsInterface extends BaseInterface {}
