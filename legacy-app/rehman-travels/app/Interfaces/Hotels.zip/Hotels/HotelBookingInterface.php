<?php

namespace App\Interfaces\Hotels;

use App\Interfaces\BaseInterface;

interface HotelBookingInterface extends BaseInterface {}
