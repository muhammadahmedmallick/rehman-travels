<?php

namespace App\Interfaces\Hotels;

use App\Interfaces\BaseInterface;

interface HotelBookingRoomsInterface extends BaseInterface {}
